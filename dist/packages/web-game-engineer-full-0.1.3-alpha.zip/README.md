# Web & Game Engineer

**Release:** 0.1.3-alpha · **Channel:** Alpha · **Certification:** no platform certified

A cross-AI engineering Skill with one shared Core, nine professional modules, seven virtual roles and independently versioned platform adapters. Platforms are used separately; no AI-to-AI communication is required.

## Download packages
Every installable Skill and platform adapter has its own matching ZIP and SHA-256 checksum. The full source bundle is also packaged. See [package download index](dist/packages/INDEX.md) and [distribution contract](release/DISTRIBUTION.md). ZIPs are generated and committed by GitHub Actions after package changes.

## Platform adapters
- **ChatGPT:** [portable package](packages/chatgpt/) · [plugin source](plugin-distribution/chatgpt/) · Experimental / NOT CERTIFIED.
- **Claude:** [portable package](packages/claude/) · [Claude Code plugin source](plugin-distribution/claude/) · Experimental / NOT CERTIFIED. Claude.ai Skills and Claude Code plugins are separate targets.
- Gemini, DeepSeek, Qwen and Doubao remain planned/Experimental; each requires its own package and independent validation.

## Start
1. Read `SKILL.md`.
2. Read the relevant platform adapter guide.
3. Download the matching platform ZIP from `dist/packages/INDEX.md`.
4. Follow only an installation path actually supported by the target account/host.
5. Run adapter acceptance tests and record evidence.

All platform certifications are independent. See `release/POLICY.md` and `release/acceptance-matrix.csv`.
